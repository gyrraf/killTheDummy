I saved all of the files three times.
Once as a ".pdf" in the folder called "pdf". If you just want to look at it, I would recommend using these.

Once in the OpenDocument format in the folder called "odf". Depending on which program you use to open these, it might not look the way it did when I created them in Microsoft Office.

Once in the Microsoft Office Version in the folder called "Microsoft_Office". If you want to inspect the documents in the form I created them, I would suggest using these and opening them in the corresponding Microsoft Office Program.



NOTE:

Microsoft Excel warned me that somethings might not work anymore when saved as a ".ods"-file. (".ods" is the OpenDocument file extension for spreadsheets.) I checked with both Microsoft Excel and LibreOffice Calc and didn't find anything major. (The sizes don't match up with each other.)

Microsoft Visio doesn't allow the usage of ".odg" at all. (".odg" is the OpenDocument file extension for graphics.) I had to open it with LibreOffice Draw and save it from there. It can't be opened with Microsoft Visio but it can be opened with LibreOffice Draw. (The sizes don't match up with each other again.)
